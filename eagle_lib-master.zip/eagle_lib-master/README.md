# eagle_lib
CadSoft EAGLE library, includes following parts and modules:

* Arduino Nano R3 module
* CD4050 (HFE4050) Non-inverting buffer / logic level converter IC
* HKE HRS1H-S miniature SPST relay
* 2.2" QVGA TFT QVGA Color LCD + SDcard module (+ flash), SPI

More to come...

Aldar Altankhuyag
